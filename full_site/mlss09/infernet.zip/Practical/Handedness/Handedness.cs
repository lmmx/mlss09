﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MicrosoftResearch.Infer.Models;
using MicrosoftResearch.Infer;

namespace Handedness
{
	class Program
	{
		static void Main(string[] args)
		{
			// Data about people: true=right, false=left
			bool[] studentData = { false, true, true, true, true, true, true, true, false, false };
			bool[] lecturerData = { false, true, true, true, true, true, true, true, true, true };

			// The probabilistic program
			// -------------------------

			int numStudents = studentData.Length;
			Range student = new Range(numStudents);
			VariableArray<bool> isRightHanded = Variable.Array<bool>(student);
			using(Variable.ForEach(student)) {
				isRightHanded[student] = Variable.Bernoulli(0.9);
			}

			// Inference queries about the program
			// -----------------------------------
			InferenceEngine engine = new InferenceEngine();
			Console.WriteLine("isRightHanded = {0}", engine.Infer(isRightHanded));

			Console.WriteLine("Press any key...");
			Console.ReadKey();

			// Answer key
			// ----------
			// with no data:
			// probRightHanded = Beta(0.72,0.08)[mean=0.9]
			// with studentData:
			// probRightHanded = Beta(7.72,3.08)[mean=0.7148]
			// drawnFromGeneral = Bernoulli(0.6955)
			// with lecturerData:
			// drawnFromGeneral = Bernoulli(0.8606)
			// same or different:
			// drawnFromSame = Bernoulli(0.7355)
		}
	}
}
