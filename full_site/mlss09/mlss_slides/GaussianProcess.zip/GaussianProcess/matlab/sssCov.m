function K = sssCov(x1,x2,numFreqs)

% function K = sssCov(x1,x2,numFreqs)
%
% compute a Sparse Sampled Spectral GP covariance function based on the
% spectrum of the squared exponential

distances = 2*sqrt(sq_dist(x1',x2'));

w = 0.5*randn(numFreqs,1);

K = zeros(size(x1,1),size(x2,1));

for i = 1:numFreqs
    K  = K + cos(w(i)*distances);
end

K = K/numFreqs;
