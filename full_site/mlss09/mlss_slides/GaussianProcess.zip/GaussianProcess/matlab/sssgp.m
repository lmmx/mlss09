% add the path to the gplm code from Carl Rasmussen and Chris Williams
% book
addpath('gpml-matlab\gpml\')

% initialize random number generator
randn('seed',1);
rand('seed',1);

% generate a set of training inputs
x = [-3; -1; 0; 2; 2.5; 3; 4];
n = length(x);
Kx = exp(-0.5*sq_dist(x',x')/1);      % lengthscale 1
y = chol(Kx)*randn(n,1) + 0.2*(rand(n,1) - 0.5); % add noise of width 0.2

% generate a set of test inputs
xte = [-12:0.1:12]'; 
nte = size(xte,1);

figure(101),clf
% plot the training data
plot(x, y, 'k+', 'MarkerSize', 17)
axis([-7 7 -2 3])
hold on

% covariance matrices
Kfull = exp(-0.5*sq_dist(xte',xte')/1);      % lengthscale 1
K1 = sssCov(xte,xte,3);
K2 = sssCov(xte,xte,400);


% samples from prior
[U,D] = eig(Kfull); Rfull = U*sqrt(abs(D));
[U,D] = eig(K1); R1 = U*sqrt(abs(D));
[U,D] = eig(K2); R2 = U*sqrt(abs(D));
figure(302),clf
subplot(321)
plot(xte,Rfull*randn(nte,5));
title('full prior')
subplot(323)
plot(xte,R1*randn(nte,5));
title('3 frequencies cos-sin model')
subplot(325)
plot(xte,R2*randn(nte,5));
title('400 frequencies cos-sin model')

% find index 
[kk,ixd,ix] = intersect(x,xte);

% means and variances
mfull = Kfull(:,ix)*inv(Kfull(ix,ix)+1e-4*eye(length(x)))*y;
m1 = K1(:,ix)*inv(K1(ix,ix)+1e-4*eye(length(x)))*y;
m2 = K2(:,ix)*inv(K2(ix,ix)+1e-4*eye(length(x)))*y;
vfull = diag(Kfull) - sum( (Kfull(:,ix)*inv(Kfull(ix,ix)+1e-4*eye(length(x)))) .*Kfull(:,ix),2);
v1 = diag(K1) - sum( (K1(:,ix)*inv(K1(ix,ix)+1e-4*eye(length(x)))) .*K1(:,ix),2);
v2 = diag(K2) - sum( (K2(:,ix)*inv(K2(ix,ix)+1e-4*eye(length(x)))) .*K2(:,ix),2);


figure(302)
subplot(322)
plot(xte,mfull);
hold on
plot(xte,mfull+2*sqrt(vfull),':');
plot(xte,mfull-2*sqrt(vfull),':');
plot(x,y,'k+');
title('full prior')
subplot(324)
plot(xte,m1);
hold on
plot(xte,m1+2*sqrt(v1),':');
plot(xte,m1-2*sqrt(v1),':');
plot(x,y,'k+');
title('3 frequencies cos-sin model')
subplot(326)
plot(xte,m2);
hold on
plot(xte,m2+2*sqrt(v2),':');
plot(xte,m2-2*sqrt(v2),':');
plot(x,y,'k+');
title('400 frequencies cos-sin model')
