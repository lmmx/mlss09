clear all

% add the path to the gpml code from Carl Rasmussen and Chris Williams
% book
addpath('gpml-matlab\gpml\')

% initialize random number generator
randn('seed',1);
rand('seed',1);

% generate a set of training targets
x = [-3; 0; 2; 3; 5];
n = length(x);
Kx = exp(-0.5*sq_dist(x',x')/1^2);      % covariance, lengthscale 1
%%%%% CUT
y =  % sample a clean function values and add noise of width 0.4
%%%%% ENDCUT

% generate a set of test inputs
xte = (-8:0.1:8)'; 
nte = size(xte,1);

figure(101),clf
% plot the training data
plot(x, y, 'k+', 'MarkerSize', 17)
axis([-7 7 -2 3])
title('Training data and sample functions from GP priors')
hold on

% build four covariance matrices from squared exponential covariance
% function with lengthscale 0.5, 1, 2 and 3 and constant amplitude 1
K1 = exp(-0.5*sq_dist(xte',xte')/0.5^2);    % lengthscale 0.5
K2 = exp(-0.5*sq_dist(xte',xte')/1^2);      % lengthscale 1
K3 = exp(-0.5*sq_dist(xte',xte')/2^2);    % lengthscale 2
K4 = exp(-0.5*sq_dist(xte',xte')/3^2);    % lengthscale 3

% compute factorization matrices R = U*D^0.5 where U are the eigenvectors
% and D the eigenvalues. Cannot use Cholesky because of zero observation
% noise - covariance matrices are close to singular.
[U,D] = eig(K1); R1 = U*sqrt(abs(D));
[U,D] = eig(K2); R2 = U*sqrt(abs(D));
[U,D] = eig(K3); R3 = U*sqrt(abs(D));
[U,D] = eig(K4); R4 = U*sqrt(abs(D));

% plot 5 samples from all four priors
gr = [0 0.7 0];
plot(xte,R1*randn(nte,5),'color',gr);
plot(xte,R2*randn(nte,5),'b');
plot(xte,R3*randn(nte,5),'r');
plot(xte,R4*randn(nte,5),'m');

% find index 
[kk,ixd,ix] = intersect(x,xte);

% sample from the prior and accept according to the likelihood:
% uniform noise centered around the targets of width 0.4
chunksize = 10000; % size of sample chunk
totalsamples = 1000000; % total number of samples desired

% covariance 1
randn('seed',3);
fval1 = [];
numsamples = 0;
while numsamples <= totalsamples
    F = R1*randn(nte,chunksize);
    %%%%% CUT

    fval1 = [fval1 % accumulate valid sampled functions 
    %%%%% ENDCUT
    numsamples = numsamples + chunksize;
end
% plot the results
figure(102),clf
subplot(411), cla, hold on
plot(xte,fval1,'color',gr);
plot(x, y, 'k+', 'LineWidth', 2, 'MarkerSize', 17)
axis([-7 7 -2 3])
title('model 1')


% covariance 2
randn('seed',3);
fval2 = [];
numsamples = 0;
while numsamples <= totalsamples
    F = R2*randn(nte,chunksize);
    %%%%% CUT
    %%%%% ENDCUT
    numsamples = numsamples + chunksize;
end
% plot the results
subplot(412), cla, hold on
plot(xte,fval2,'b');
plot(x, y, 'k+', 'LineWidth', 2, 'MarkerSize', 17)
axis([-7 7 -2 3])
title('model 2')


% covariance 3
randn('seed',3);
fval3 = [];
numsamples = 0;
while numsamples <= totalsamples
    F = R3*randn(nte,chunksize);
    %%%%% CUT
    %%%%% ENDCUT
    numsamples = numsamples + chunksize;
end
% plot the results
subplot(413), cla, hold on
plot(xte,fval3,'r');
plot(x, y, 'k+', 'LineWidth', 2, 'MarkerSize', 17)
axis([-7 7 -2 3])
title('model 3')


% covariance 4
randn('seed',3);
fval4 = [];
numsamples = 0;
while numsamples <= totalsamples
    F = R4*randn(nte,chunksize);
    %%%%% CUT
    %%%%% ENDCUT
    numsamples = numsamples + chunksize;
end
% plot the results
subplot(414), cla, hold on
plot(xte,fval4,'m');
plot(x, y, 'k+', 'LineWidth', 2, 'MarkerSize', 17)
axis([-7 7 -2 3])
title('model 4')

%
% EVIDENCE: compute it for all four models. Which is largest?
%
% each likelihood term contributes 1/0.4 
%%%%% CUT
Evidence1 = 
Evidence2 = 
Evidence3 = 
Evidence4 = 
%%%%% ENDCUT
figure(104),clf
bar([1 2 3 4], [Evidence1 Evidence2 Evidence3 Evidence4])
xlabel('model number')
ylabel('evidence (or marginal likelihood)')

%
% PREDICTIVE Distribution
%
% we can compute the empirical means and variances
%%%%% CUT
m1 = 
m2 = 
m3 = 
m4 = 
m_all = 
%%%%% ENDCUT

figure(105), clf
subplot(511), cla, hold on
plot(xte,m1,'color',gr)
plot(xte,m1+2*sqrt(v1),'--','color',gr)
plot(xte,m1-2*sqrt(v1),'--','color',gr)
plot(x, y, 'k+', 'LineWidth', 2, 'MarkerSize', 17)
axis([-7 7 -2 3])
title('model 1')
subplot(512), cla, hold on
plot(xte,m2,'b')
plot(xte,m2+2*sqrt(v2),'b--')
plot(xte,m2-2*sqrt(v2),'b--')
plot(x, y, 'k+', 'LineWidth', 2, 'MarkerSize', 17)
axis([-7 7 -2 3])
title('model 2')
subplot(513), cla, hold on
plot(xte,m3,'r')
plot(xte,m3+2*sqrt(v3),'r--')
plot(xte,m3-2*sqrt(v3),'r--')
plot(x, y, 'k+', 'LineWidth', 2, 'MarkerSize', 17)
axis([-7 7 -2 3])
title('model 3')

subplot(514), cla, hold on
plot(xte,m4,'m')
plot(xte,m4+2*sqrt(v4),'m--')
plot(xte,m4-2*sqrt(v4),'m--')
plot(x, y, 'k+', 'LineWidth', 2, 'MarkerSize', 17)
axis([-7 7 -2 3])
title('model 4')

subplot(515), cla, hold on
plot(xte,m_all,'k:')
plot(xte,m_all+2*sqrt(v_all),'k--')
plot(xte,m_all-2*sqrt(v_all),'k--')
plot(x, y, 'k+', 'LineWidth', 2, 'MarkerSize', 17)
axis([-7 7 -2 3])
title('average model')

